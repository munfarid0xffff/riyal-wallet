# Riyal Wallet (Android)

محفظة RiyalCoin مستقلة: مفاتيح ML-DSA-44 مشفرة بـ Android Keystore (AES-256-GCM)، توقيع المعاملات داخل التطبيق،
وتتصل بعقدة عبر RPC (الافتراضي `http://127.0.0.1:19922` = عقدة Termux على نفس الهاتف).

## البناء بدون حاسوب (GitHub Actions)
1. أنشئ مستودعًا فارغًا على github.com.
2. في Termux: `pkg install git`، ثم داخل هذا المجلد:
   `git init -b main && git add . && git commit -m init`
   `git remote add origin https://github.com/USER/REPO.git && git push -u origin main`
   (كلمة المرور = Personal Access Token)
3. تبويب Actions ← Build APK ← بعد النجاح نزّل artifact باسم riyalcoin-wallet-apk ← فك الضغط وثبّت `app-debug.apk`.

## البناء المحلي
Android Studio: Open ← Build ← Build APK(s).
