package org.riyalcoin.wallet

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** JSON-RPC client for a RiyalCoin node (must be called off the UI thread). */
object Rpc {
    fun call(base: String, method: String, params: JSONArray = JSONArray()): Any {
        val c = URL(base.trimEnd('/') + "/").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 8000
        c.readTimeout = 20000
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use { it.write(JSONObject().put("method", method).put("params", params).toString().toByteArray()) }
        val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
        val j = JSONObject(stream.bufferedReader().readText())
        if (!j.isNull("error")) throw Exception(j.get("error").toString())
        return j.get("result")
    }
}

/** Keys encrypted with an AES-256-GCM key held in the Android Keystore. */
class Store(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("riyal", Context.MODE_PRIVATE)

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey("riyal-wallet", null) as? SecretKey)?.let { return it }
        val g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        g.init(KeyGenParameterSpec.Builder("riyal-wallet", KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256).build())
        return g.generateKey()
    }

    fun save(k: Keys) {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key())
        val ct = c.doFinal(k.pk + k.sk)
        prefs.edit().putString("w", Base64.encodeToString(c.iv + ct, Base64.NO_WRAP)).apply()
    }

    fun load(): Keys? {
        val s = prefs.getString("w", null) ?: return null
        val b = Base64.decode(s, Base64.NO_WRAP)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, b.copyOfRange(0, 12)))
        val p = c.doFinal(b, 12, b.size - 12)
        return Keys(p.copyOfRange(0, PK_LEN), p.copyOfRange(PK_LEN, p.size))
    }

    var nodeUrl: String
        get() = prefs.getString("url", "http://127.0.0.1:19922") ?: "http://127.0.0.1:19922"
        set(v) { prefs.edit().putString("url", v).apply() }
}
