package org.riyalcoin.wallet

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val green = Color.parseColor("#2E9E4F")
    private val dark = Color.parseColor("#14231A")
    private val hrps = mapOf("main" to "rc", "test" to "rx", "test4" to "rx", "signet" to "rx", "regtest" to "rcpc")

    private lateinit var store: Store
    private lateinit var root: LinearLayout
    private var keys: Keys? = null
    private var hrp = "rc"
    private var address = ""

    private var balView: TextView? = null
    private var spendView: TextView? = null
    private var addrView: TextView? = null
    private var statusView: TextView? = null
    private var urlEdit: EditText? = null
    private var toEdit: EditText? = null
    private var amtEdit: EditText? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE) // no screenshots
        store = Store(this)
        keys = try { store.load() } catch (e: Exception) { null }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(40), dp(16), dp(24))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        setContentView(ScrollView(this).apply { setBackgroundColor(Color.parseColor("#F4F7F5")); addView(root) })
        render()
    }

    override fun onResume() { super.onResume(); if (keys != null && urlEdit != null) refresh() }

    // ---------- helpers ----------
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun ui(f: () -> Unit) = runOnUiThread { f() }

    private fun tv(text: String, size: Float = 15f, color: Int = dark, bold: Boolean = false) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(4), 0, dp(4))
    }

    private fun btn(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text; setTextColor(Color.WHITE)
        background = GradientDrawable().apply { setColor(green); cornerRadius = dp(12).toFloat() }
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(10) }
    }

    private fun edit(hint: String) = EditText(this).apply {
        this.hint = hint; textDirection = View.TEXT_DIRECTION_LTR; setSingleLine(true); setTextColor(dark)
    }

    private fun card(color: Int = Color.WHITE) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(14))
        background = GradientDrawable().apply { setColor(color); cornerRadius = dp(16).toFloat() }
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(12) }
    }

    private fun copy(label: String, text: String) {
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText(label, text))
        toast("تم النسخ")
    }

    private fun render() {
        root.removeAllViews()
        balView = null; spendView = null; addrView = null; statusView = null; urlEdit = null; toEdit = null; amtEdit = null
        if (keys == null) onboarding() else mainScreen()
    }

    // ---------- onboarding ----------
    private fun onboarding() {
        root.addView(tv("محفظة RiyalCoin", 26f, bold = true))
        root.addView(tv("توقيعات ML-DSA-44 مقاومة للحوسبة الكمومية\nالحد الأقصى للعملات: 18,000,000", 14f, Color.parseColor("#5D6F64")))
        val c = card()
        c.addView(btn("إنشاء محفظة جديدة") {
            val k = Crypto.keygen(); store.save(k); keys = k; render()
        })
        root.addView(c)
        val c2 = card()
        c2.addView(tv("استيراد محفظة (wallet.json من عقدة Rust)", 14f, bold = true))
        val imp = EditText(this).apply { hint = "{\"pk\":\"...\",\"sk\":\"...\"}"; minLines = 4; textDirection = View.TEXT_DIRECTION_LTR; setTextColor(dark) }
        c2.addView(imp)
        c2.addView(btn("استيراد") {
            try {
                val j = JSONObject(imp.text.toString())
                val k = Keys(fromHex(j.getString("pk")), fromHex(j.getString("sk")))
                Crypto.check(k); store.save(k); keys = k; render()
            } catch (e: Exception) { toast("فشل الاستيراد: " + (e.message ?: e.toString())) }
        })
        root.addView(c2)
    }

    // ---------- main screen ----------
    private fun mainScreen() {
        val head = tv("محفظة RiyalCoin", 22f, bold = true)
        root.addView(head)

        val bal = card(green)
        bal.addView(tv("الرصيد الكلي", 13f, Color.WHITE))
        balView = tv("—", 24f, Color.WHITE, true).apply { textDirection = View.TEXT_DIRECTION_LTR }
        bal.addView(balView)
        spendView = tv("القابل للإنفاق: —", 13f, Color.WHITE)
        bal.addView(spendView)
        root.addView(bal)

        val a = card()
        a.addView(tv("عنوانك للاستلام (اضغط للنسخ)", 13f, Color.parseColor("#5D6F64")))
        addrView = tv("—", 13f).apply {
            textDirection = View.TEXT_DIRECTION_LTR
            setOnClickListener { if (address.isNotEmpty()) copy("address", address) }
        }
        a.addView(addrView)
        root.addView(a)

        val n = card()
        n.addView(tv("عنوان العقدة (RPC)", 13f, Color.parseColor("#5D6F64")))
        urlEdit = edit("http://127.0.0.1:19922").apply { setText(store.nodeUrl) }
        n.addView(urlEdit)
        n.addView(btn("تحديث") { refresh() })
        statusView = tv("", 13f)
        n.addView(statusView)
        root.addView(n)

        val s = card()
        s.addView(tv("إرسال", 16f, bold = true))
        toEdit = edit("العنوان المستلم (rc1...)")
        amtEdit = edit("المبلغ بالـ Riyal").apply { inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL }
        s.addView(toEdit); s.addView(amtEdit)
        s.addView(tv("الرسوم الثابتة: ${fmtAmount(MIN_FEE)} Riyal", 12f, Color.parseColor("#5D6F64")))
        s.addView(btn("إرسال") { confirmSend() })
        root.addView(s)

        val b = card()
        b.addView(btn("نسخ احتياطي للمفاتيح (حساس!)") { confirmBackup() })
        root.addView(b)

        refresh()
    }

    private fun refresh() {
        val k = keys ?: return
        val url = urlEdit?.text?.toString()?.trim().orEmpty()
        if (url.isEmpty()) return
        store.nodeUrl = url
        statusView?.text = "جارٍ الاتصال…"
        thread {
            try {
                val info = Rpc.call(url, "getblockchaininfo") as JSONObject
                val chain = info.getString("chain")
                hrp = hrps[chain] ?: throw Exception("شبكة غير معروفة: $chain")
                address = Crypto.address(hrp, k.pk)
                val list = Rpc.call(url, "listunspent", JSONArray().put(address)) as JSONArray
                var total = 0L; var spend = 0L
                for (i in 0 until list.length()) {
                    val u = list.getJSONObject(i)
                    total += u.getLong("value")
                    if (u.getBoolean("mature")) spend += u.getLong("value")
                }
                ui {
                    balView?.text = fmtAmount(total) + " Riyal"
                    spendView?.text = "القابل للإنفاق: " + fmtAmount(spend)
                    addrView?.text = address
                    statusView?.text = "متصل — الشبكة: $chain — الارتفاع: ${info.getLong("blocks")}"
                }
            } catch (e: Exception) {
                ui { statusView?.text = "خطأ: " + (e.message ?: e.toString()) }
            }
        }
    }

    private fun confirmSend() {
        val to = toEdit?.text?.toString()?.trim().orEmpty()
        val dest = Bech32.decode(to, hrp) ?: return toast("عنوان غير صالح لهذه الشبكة ($hrp)")
        val amt = parseAmount(amtEdit?.text?.toString().orEmpty()) ?: return toast("مبلغ غير صالح")
        if (amt <= 0) return toast("المبلغ يجب أن يكون أكبر من صفر")
        AlertDialog.Builder(this).setTitle("تأكيد الإرسال")
            .setMessage("إرسال ${fmtAmount(amt)} Riyal\nإلى:\n$to\n\nالرسوم: ${fmtAmount(MIN_FEE)}\nلا يمكن التراجع.")
            .setPositiveButton("إرسال") { _, _ -> send(dest, amt) }
            .setNegativeButton("إلغاء", null).show()
    }

    private fun send(dest: ByteArray, amt: Long) {
        val k = keys ?: return
        val url = urlEdit?.text?.toString()?.trim().orEmpty()
        statusView?.text = "جارٍ التوقيع والإرسال…"
        thread {
            try {
                val list = Rpc.call(url, "listunspent", JSONArray().put(address)) as JSONArray
                val cands = (0 until list.length()).map { list.getJSONObject(it) }
                    .filter { it.getBoolean("mature") }.sortedByDescending { it.getLong("value") }
                val need = amt + MIN_FEE
                var total = 0L
                val ins = ArrayList<TxIn>()
                for (u in cands) {
                    ins.add(TxIn(fromHex(u.getString("txid")), u.getInt("vout")))
                    total += u.getLong("value")
                    if (total >= need) break
                }
                if (total < need) throw Exception("الرصيد القابل للإنفاق غير كافٍ")
                val outs = arrayListOf(TxOut(amt, dest))
                if (total > need) outs.add(TxOut(total - need, Crypto.sha256(k.pk)))
                val id = Tx.txid(ins, outs)
                val sig = Crypto.sign(k.sk, id)
                if (!Crypto.verify(k.pk, id, sig)) throw Exception("فشل الفحص الذاتي للتوقيع")
                val raw = Tx.serialize(ins, outs, k.pk, sig)
                if (raw.size > 100_000) throw Exception("عدد المدخلات كبير؛ أرسل مبلغًا أصغر")
                val res = Rpc.call(url, "sendrawtransaction", JSONArray().put(toHex(raw))) as String
                ui { statusView?.text = "تم الإرسال. المعرّف:\n$res"; amtEdit?.setText("") }
            } catch (e: Exception) {
                ui { statusView?.text = "فشل الإرسال: " + (e.message ?: e.toString()) }
            }
        }
    }

    private fun confirmBackup() {
        AlertDialog.Builder(this).setTitle("نسخ المفاتيح")
            .setMessage("سيُنسخ المفتاح الخاص إلى الحافظة بصيغة wallet.json. أي شخص يملكه يملك أموالك. الصقه في مكان آمن ثم امسح الحافظة.")
            .setPositiveButton("نسخ") { _, _ ->
                val k = keys ?: return@setPositiveButton
                copy("wallet", JSONObject().put("pk", toHex(k.pk)).put("sk", toHex(k.sk)).toString())
            }.setNegativeButton("إلغاء", null).show()
    }
}
