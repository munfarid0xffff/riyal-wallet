package org.riyalcoin.wallet

import org.bouncycastle.crypto.params.ParametersWithContext
import org.bouncycastle.crypto.params.ParametersWithRandom
import org.bouncycastle.pqc.crypto.mldsa.MLDSAKeyGenerationParameters
import org.bouncycastle.pqc.crypto.mldsa.MLDSAKeyPairGenerator
import org.bouncycastle.pqc.crypto.mldsa.MLDSAParameters
import org.bouncycastle.pqc.crypto.mldsa.MLDSAPrivateKeyParameters
import org.bouncycastle.pqc.crypto.mldsa.MLDSAPublicKeyParameters
import org.bouncycastle.pqc.crypto.mldsa.MLDSASigner
import java.io.ByteArrayOutputStream
import java.security.MessageDigest
import java.security.SecureRandom

const val COIN = 100_000_000_000L          // 1 Riyal = 10^11 millipiaster
const val MIN_FEE = COIN / 10_000
const val PK_LEN = 1312
val CTX = "RiyalCoin-v1-tx".toByteArray()  // must equal CTX in the Rust node

class Keys(val pk: ByteArray, val sk: ByteArray)
class TxIn(val txid: ByteArray, val vout: Int)
class TxOut(val value: Long, val addr: ByteArray)

fun toHex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }
fun fromHex(s: String): ByteArray {
    require(s.length % 2 == 0) { "bad hex" }
    return ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
}

fun fmtAmount(v: Long) = "%d.%011d".format(v / COIN, v % COIN)

fun parseAmount(s: String): Long? {
    val t = s.trim()
    val i = t.substringBefore('.')
    val f = if (t.contains('.')) t.substringAfter('.') else ""
    if (i.isEmpty() || !i.all { it.isDigit() } || !f.all { it.isDigit() } || f.length > 11) return null
    val ip = i.toLongOrNull() ?: return null
    val fp = f.padEnd(11, '0').toLongOrNull() ?: return null
    return try { Math.addExact(Math.multiplyExact(ip, COIN), fp) } catch (e: ArithmeticException) { null }
}

object Crypto {
    private val P: MLDSAParameters = MLDSAParameters.ml_dsa_44

    fun sha256(b: ByteArray): ByteArray = MessageDigest.getInstance("SHA-256").digest(b)
    fun sha256d(b: ByteArray) = sha256(sha256(b))

    fun keygen(): Keys {
        val g = MLDSAKeyPairGenerator()
        g.init(MLDSAKeyGenerationParameters(SecureRandom(), P))
        val kp = g.generateKeyPair()
        return Keys((kp.public as MLDSAPublicKeyParameters).encoded, (kp.private as MLDSAPrivateKeyParameters).encoded)
    }

    fun sign(sk: ByteArray, msg: ByteArray): ByteArray {
        val s = MLDSASigner()
        s.init(true, ParametersWithContext(ParametersWithRandom(MLDSAPrivateKeyParameters(P, sk), SecureRandom()), CTX))
        return s.generateSignature(msg)
    }

    fun verify(pk: ByteArray, msg: ByteArray, sig: ByteArray): Boolean {
        val s = MLDSASigner()
        s.init(false, ParametersWithContext(MLDSAPublicKeyParameters(P, pk), CTX))
        return s.verifySignature(msg, sig)
    }

    /** Throws if the pk/sk pair is invalid or mismatched. */
    fun check(k: Keys) {
        require(k.pk.size == PK_LEN) { "bad public key size" }
        val m = "riyal-selftest".toByteArray()
        require(verify(k.pk, m, sign(k.sk, m))) { "public key does not match secret key" }
    }

    fun address(hrp: String, pk: ByteArray) = Bech32.encode(hrp, sha256(pk))
}

/** Byte-exact twin of the Rust node's bincode (fixint, little-endian) transaction encoding. */
object Tx {
    private fun w(o: ByteArrayOutputStream, v: Long, n: Int) { for (i in 0 until n) o.write(((v ushr (8 * i)) and 0xff).toInt()) }
    private fun vec(o: ByteArrayOutputStream, b: ByteArray) { w(o, b.size.toLong(), 8); o.write(b) }

    fun serialize(ins: List<TxIn>, outs: List<TxOut>, pk: ByteArray?, sig: ByteArray?): ByteArray {
        val o = ByteArrayOutputStream()
        w(o, 1, 4)                              // version
        w(o, ins.size.toLong(), 8)
        for (i in ins) { o.write(i.txid); w(o, i.vout.toLong(), 4); vec(o, pk ?: ByteArray(0)); vec(o, sig ?: ByteArray(0)) }
        w(o, outs.size.toLong(), 8)
        for (t in outs) { w(o, t.value, 8); o.write(t.addr) }
        vec(o, ByteArray(0))                    // memo
        return o.toByteArray()
    }

    /** txid = sha256d(tx without pubkeys/signatures) */
    fun txid(ins: List<TxIn>, outs: List<TxOut>) = Crypto.sha256d(serialize(ins, outs, null, null))
}

object Bech32 {
    private const val CHARSET = "qpzry9x8gf2tvdw0s3jn54khce6mua7l"
    private val GEN = intArrayOf(0x3b6a57b2, 0x26508e6d, 0x1ea119fa, 0x3d4233dd, 0x2a1462b3)

    private fun polymod(values: IntArray): Int {
        var chk = 1
        for (v in values) {
            val b = chk ushr 25
            chk = ((chk and 0x1ffffff) shl 5) xor v
            for (i in 0 until 5) if (((b ushr i) and 1) == 1) chk = chk xor GEN[i]
        }
        return chk
    }

    private fun hrpExpand(hrp: String): IntArray {
        val r = IntArray(hrp.length * 2 + 1)
        for (i in hrp.indices) { r[i] = hrp[i].code ushr 5; r[i + hrp.length + 1] = hrp[i].code and 31 }
        return r
    }

    private fun convert(data: IntArray, from: Int, to: Int, pad: Boolean): IntArray? {
        var acc = 0; var bits = 0
        val out = ArrayList<Int>()
        val maxv = (1 shl to) - 1
        val maxAcc = (1 shl (from + to - 1)) - 1
        for (v in data) {
            if ((v ushr from) != 0) return null
            acc = ((acc shl from) or v) and maxAcc
            bits += from
            while (bits >= to) { bits -= to; out.add((acc ushr bits) and maxv) }
        }
        if (pad) { if (bits > 0) out.add((acc shl (to - bits)) and maxv) }
        else if (bits >= from || ((acc shl (to - bits)) and maxv) != 0) return null
        return out.toIntArray()
    }

    fun encode(hrp: String, data: ByteArray): String {
        val d5 = convert(IntArray(data.size) { data[it].toInt() and 0xff }, 8, 5, true)!!
        val mod = polymod(hrpExpand(hrp) + d5 + IntArray(6)) xor 1
        val checksum = IntArray(6) { (mod ushr (5 * (5 - it))) and 31 }
        return hrp + "1" + (d5 + checksum).map { CHARSET[it] }.joinToString("")
    }

    /** Returns the 32-byte payload, or null if invalid / wrong network prefix. */
    fun decode(s: String, hrp: String): ByteArray? {
        val str = s.trim().lowercase()
        val pos = str.lastIndexOf('1')
        if (pos < 1 || pos + 7 > str.length) return null
        if (str.substring(0, pos) != hrp) return null
        val data = IntArray(str.length - pos - 1)
        for (i in data.indices) {
            val c = CHARSET.indexOf(str[pos + 1 + i])
            if (c < 0) return null
            data[i] = c
        }
        if (polymod(hrpExpand(hrp) + data) != 1) return null
        val d8 = convert(data.copyOfRange(0, data.size - 6), 5, 8, false) ?: return null
        if (d8.size != 32) return null
        return ByteArray(32) { d8[it].toByte() }
    }
}
